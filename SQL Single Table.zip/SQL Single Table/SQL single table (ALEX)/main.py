import logging
from menu_definitions import menu_main, department_select, debug_select
from db_connection import engine, Session
from orm_base import metadata
# Note that until you import your SQLAlchemy declarative classes, such as Student, Python
# will not execute that code, and SQLAlchemy will be unaware of the mapped table.
from Department import Department
from Option import Option
from Menu import Menu


def create_department(session: Session):
    """
    Prompt the user for the information for a new student and validate
    the input to make sure that we do not create any duplicates.
    :param session: The connection to the database.
    :return:        None
    """
    unique_abbreviation: bool = False
    unique_chair_name: bool = False
    unique_building: bool = False
    unique_office: bool = False
    unique_description: bool = False
    name: str = ''
    abbreviation: str = ''
    chairName: str = ''
    building: str = ''
    office: int = ''
    description: str = ''

    # Note that there is no physical way for us to duplicate the student_id since we are
    # using the Identity "type" for studentId and allowing PostgreSQL to handle that.
    # See more at: https://www.postgresqltutorial.com/postgresql-tutorial/postgresql-identity-column/
    while not unique_abbreviation or not unique_chair_name or not unique_building or not unique_office or not unique_description:
        name = input("Department name--> ")
        abbreviation = input("Department abbreviation--> ")
        chairName = input("Department chair name--> ")
        building = input("Department building--> ")
        office = input("Department office--> ")
        description = input("Department description--> ")
        name_count: int = session.query(Department).filter(Department.name == name).count()

        unique_name = name_count == 0
        if not unique_name:
            print("We already have a department by that name.  Try again.")
        if unique_name:
            name_count = session.query(Department).filter(Department.name == name).count()
            unique_name = name_count == 0
            if not unique_abbreviation:
                print("We already have a department student with that abbreviation.  Try again.")
            if not unique_chair_name:
                print("We already have a department student with that chair name.  Try again.")
            if not unique_building:
                print("We already have a department student with that building.  Try again.")
            if not unique_office:
                print("We already have a department student with that office.  Try again.")
            if not unique_description:
                print("We already have a department student with that description.  Try again.")

    newDepartment = Department(name, abbreviation, chairName, building, office, description)
    session.add(newDepartment)


def select_department_name(sess: Session) -> Department:
    """
    Prompt the user for a specific student by the student ID.  Generally
    this is not a terribly useful approach, but I have it here for
    an example.
    :param sess:    The connection to the database.
    :return:        The selected student.
    """
    found: bool = False
    name: int = -1
    while not found:
        name = str(input("Enter the department name--> "))
        name_count: int = sess.query(Department).filter(Department.name == name).count()
        found = name_count == 1
        if not found:
            print("No department with that name.  Try again.")
    return_department: Department = sess.query(Department).filter(Department.name == name).first()
    return return_department


def select_department_abbreviation(sess: Session) -> Department:
    """
    Select a student by the e-mail address.
    :param sess:    The connection to the database.
    :return:        The selected student.
    """
    found: bool = False
    abbreviation: str = ''
    while not found:
        abbreviation = input("Enter the department abbreviation--> ")
        abbreviation_count: int = sess.query(Department).filter(Department.abbreviation == abbreviation).count()
        found = abbreviation_count == 1
        if not found:
            print("No department with that abbreviation.  Try again.")
    return_department: Department = sess.query(Department).filter(Department.abbreviation == abbreviation).first()
    return return_department


def select_department_chair_name(sess: Session) -> Department:
    """
    Select a student by the e-mail address.
    :param sess:    The connection to the database.
    :return:        The selected student.
    """
    found: bool = False
    chairName: str = ''
    while not found:
        chairName = input("Enter the department chair name--> ")
        id_count: int = sess.query(Department).filter(Department.chairName == chairName).count()
        found = id_count == 1
        if not found:
            print("No department with that chair name.  Try again.")
    return_department: Department = sess.query(Department).filter(Department.chairName == chairName).first()
    return return_department


def select_department_building(sess: Session) -> Department:
    """
    Select a student by the e-mail address.
    :param sess:    The connection to the database.
    :return:        The selected student.
    """
    found: bool = False
    building: str = ''
    while not found:
        building = input("Enter the department building--> ")
        building_count: int = sess.query(Department).filter(Department.building == building).count()
        found = building_count == 1
        if not found:
            print("No department with that building.  Try again.")
    return_department: Department = sess.query(Department).filter(Department.building == building).first()
    return return_department


def select_department_office(sess: Session) -> Department:
    """
    Select a student by the e-mail address.
    :param sess:    The connection to the database.
    :return:        The selected student.
    """
    found: bool = False
    office: str = ''
    while not found:
        office = input("Enter the department office--> ")
        office_count: int = sess.query(Department).filter(Department.office == office).count()
        found = office_count == 1
        if not found:
            print("No department with that office.  Try again.")
    return_department: Department = sess.query(Department).filter(Department.office == office).first()
    return return_department


def select_department_description(sess: Session) -> Department:
    """
    Select a student by the e-mail address.
    :param sess:    The connection to the database.
    :return:        The selected student.
    """
    found: bool = False
    description: str = ''
    while not found:
        description = input("Enter the department description--> ")
        description_count: int = sess.query(Department).filter(Department.description == description).count()
        found = description_count == 1
        if not found:
            print("No department with that description.  Try again.")
    return_department: Department = sess.query(Department).filter(Department.description == description).first()
    return return_department


def find_department(sess: Session) -> Department:
    """
    Prompt the user for attribute values to select a single student.
    :param sess:    The connection to the database.
    :return:        The instance of Student that the user selected.
                    Note: there is no provision for the user to simply "give up".
    """
    find_department_command = department_select.menu_prompt()
    match find_department_command:
        case "Name":
            old_department = select_department_name(sess)
        case "Abbreviation":
            old_department = select_department_abbreviation(sess)
        case "Chair Name":
            old_department = select_department_chair_name(sess)
        case "Building":
            old_department = select_department_building(sess)
        case "Office":
            old_department = select_department_office(sess)
        case "Description":
            old_department = select_department_description(sess)
        case _:
            old_department = None
    return old_department


def delete_department(session: Session):
    """
    Prompt the user for a student by the last name and first name and delete that
    student.
    :param session: The connection to the database.
    :return:        None
    """
    print("deleting a department")
    olddepartment = find_department(session)
    session.delete(olddepartment)


def list_departments(session: Session):
    """
    List all of the students, sorted by the last name first, then the first name.
    :param session:
    :return:
    """
    # session.query returns an iterator.  The list function converts that iterator
    # into a list of elements.  In this case, they are instances of the Student class.
    departments: [Department] = list(
        session.query(Department).order_by(Department.name, Department.abbreviation, Department.chairName,
                                           Department.building, Department.office, Department.description))
    for department in departments:
        print(department)


def select_department_from_list(session):
    """
    This is just a cute little use of the Menu object.  Basically, I create a
    menu on the fly from data selected from the database, and then use the
    menu_prompt method on Menu to display characteristic descriptive data, with
    an index printed out with each entry, and prompt the user until they select
    one of the Students.
    :param session:     The connection to the database.
    :return:            None
    """
    # query returns an iterator of Student objects, I want to put those into a list.  Technically,
    # that was not necessary, I could have just iterated through the query output directly.
    departments: [Department] = list(
        sess.query(Department).order_by(Department.name, Department.abbreviation, Department.chairName,
                                        Department.building, Department.office, Department.description))
    options: [Option] = []  # The list of menu options that we're constructing.
    for department in departments:
        # Each time we construct an Option instance, we put the full name of the student into
        # the "prompt" and then the student ID (albeit as a string) in as the "action".
        options.append(Option(Department.name, Department.abbreviation, Department.chairName, Department.building,
                              Department.office, Department.description))
    temp_menu = Menu('Department list', 'Select a department from this list', options)
    # text_studentId is the "action" corresponding to the student that the user selected.
    text_name: str = temp_menu.menu_prompt()
    # get that student by selecting based on the int version of the student id corresponding
    # to the student that the user selected.
    returned_department = sess.query(Department).filter(Department.name == int(text_name)).first()
    # this is really just to prove the point.  Ideally, we would return the student, but that
    # will present challenges in the exec call, so I didn't bother.
    print("Selected department: ", returned_department)


if __name__ == '__main__':
    print('Starting off')
    logging.basicConfig()
    # use the logging factory to create our first logger.
    # for more logging messages, set the level to logging.DEBUG.
    # logging_action will be the text string name of the logging level, for instance 'logging.INFO'
    logging_action = debug_select.menu_prompt()
    # eval will return the integer value of whichever logging level variable name the user selected.
    logging.getLogger("sqlalchemy.engine").setLevel(eval(logging_action))
    # use the logging factory to create our second logger.
    # for more logging messages, set the level to logging.DEBUG.
    logging.getLogger("sqlalchemy.pool").setLevel(eval(logging_action))

    metadata.drop_all(bind=engine)  # start with a clean slate while in development

    # Create whatever tables are called for by our "Entity" classes.
    metadata.create_all(bind=engine)

    with Session() as sess:
        main_action: str = ''
        while main_action != menu_main.last_action():
            main_action = menu_main.menu_prompt()
            print('next action: ', main_action)
            exec(main_action)
        sess.commit()
    print('Ending normally')