import logging
from menu_definitions import menu_main, department_select, debug_select
from db_connection import engine, Session
from orm_base import metadata

from Department import Department
from Option import Option
from Menu import Menu


def add_department(session: Session):
    """
    :param session:
    :return:
    """
    unique_abbreviation: bool = False
    unique_chair: bool = False
    unique_building: bool = False
    unique_description: bool = False
    name: str = ''
    abbreviation: str = ''
    chairName: str = ''
    building: str = ''
    office: int = -1
    description: str = ''

    name = input("Department Name--> ")
    name_count: int = session.query(Department).filter(Department.name == name).count()
    while not unique_abbreviation:
        abbreviation = input("Department abbreviation--> ")
        abbreviation_count: int = session.query(Department).filter(Department.abbreviation == abbreviation).count()
        unique_abbreviation = abbreviation_count == 0
        if not unique_abbreviation:
            print("We already have a department with this abbreviation. Try again.")
    while not unique_chair:
        chairName = input("Department Chair Name--> ")
        chair_count: int = session.query(Department).filter(Department.chairName == chairName).count()
        unique_chair = chair_count == 0
        if not unique_chair:
            print("We already have a department with this abbreviation. Try again.")
    while not unique_building:
        building = input("Department building name--> ")
        office = int(input("Department office number--> "))
        building_count: int = session.query(Department).filter(Department.building == building,
                                                               Department.office == office).count()
        unique_building = building_count == 0
        if not unique_building:
            print("We already have a Department in this location. Try Again.")
    while not unique_description:
        description = input("Department description--> ")
        description_count: int = session.query(Department).filter(Department.description == description).count()
        unique_description = description_count == 0
        if not unique_description:
            print("We already have a department with this description. Try again.")

    newDepartment = Department(name, abbreviation, chairName, building, office, description)
    session.add(newDepartment)


def select_abbreviation(sess: Session) -> Department:
    """
    :param sess:
    :return:
    """
    found: bool = False
    abbrev: str = ''
    while not found:
        abbrev = input("Enter the abbreviation--> ")
        abbrev_count: int = sess.query(Department).filter(Department.abbreviation == abbrev).count()
        found = abbrev_count == 1
        if not found:
            print("No department with this abbreviation. Try again.")
        return_department: Department = sess.query(Department).filter(Department.abbreviation == abbrev).first()
        return return_department


def select_chair_name(sess:Session) -> Department:
    """
    :param sess:
    :return:
    """
    found: bool = False
    chair: str = ''
    while not found:
        chair = input("Department chair name--> ")
        chair_count: int = sess.query(Department).filter(Department.chairName == chair).count()
        found = chair_count == 1
        if not found:
            print("No department chair with this name. Try again.")
    oldDepartment = sess.query(Department).filter(Department.chairName == chair).first()
    return oldDepartment


def select_building_and_office(sess: Session) -> Department:
    """
    :param sess:
    :return:
    """
    found: bool = False
    build: str = ''
    office: int = -1
    while not found:
        build = input("Department building name--> ")
        office = int(input("Department office number--> "))
        building_count: int = sess.query(Department).filter(Department.building == build,
                                                            Department.office == office).count()
        found = building_count == 1
        if not found: 
            print("No Department found at this building and office. Try again.")
    oldDepartment = sess.query(Department).filter(Department.building == build,
                                                  Department.office == office).first()
    return oldDepartment


def select_description(sess: Session) -> Department:
    """
    :param sess:
    :return:
    """
    found: bool = False
    describe: str = ''
    while not found:
        describe = input("Department description--> ")
        description_count: int = sess.query(Department).filter(Department.description == describe).count()
        found = description_count == 1
        if not found:
            print("No department of this description. Try again.")
    oldDepartment = sess.query(Department).filter(Department.description == describe).first()
    return oldDepartment


def find_department(sess: Session) -> Department:
    find_department_command = department_select.menu_prompt()
    match find_department_command:
        case "abbreviation":
            old_department = select_abbreviation(sess)
        case "chair name":
            old_department = select_chair_name(sess)
        case "building/ office":
            old_department = select_building_and_office(sess)
        case "description":
            old_department = select_description(sess)
        case _:
            old_department = None
    return old_department


def delete_department(session: Session):
    """
    :param:
    :return:
    """
    print("deleting a department")
    oldDepartment = find_department(session)
    session.delete(oldDepartment)


def list_departments(session: Session):
    """
    :param:
    :return:
    """
    departments: [Department] = list(session.query(Department).order_by(Department.name))
    for department in departments:
        print(department)


def select_department_from_list(session: Session):
    departments: [Department] = list(session.query(Department).order_by(Department.name))
    options: [Option] = []
    for department in departments:
        options.append(Option(department.name, department.abbreviation))
    temp_menu = Menu('Student list', 'Select a student from this list', options)

    text_department_name: str = temp_menu.menu_prompt()
    returned_department = session.query(Department).filter(Department.name == text_department_name).first()

    print("Selected student: ", returned_department)


if __name__ == '__main__':
    print('Starting off')
    logging.basicConfig()
    # use the logging factory to create our first logger.
    # for more logging messages, set the level to logging.DEBUG.
    # logging_action will be the text string name of the logging level, for instance 'logging.INFO'
    logging_action = debug_select.menu_prompt()
    # eval will return the integer value of whichever logging level variable name the user selected.
    logging.getLogger("sqlalchemy.engine").setLevel(eval(logging_action))
    # use the logging factory to create our second logger.
    # for more logging messages, set the level to logging.DEBUG.
    logging.getLogger("sqlalchemy.pool").setLevel(eval(logging_action))

    metadata.drop_all(bind=engine)  # start with a clean slate while in development

    # Create whatever tables are called for by our "Entity" classes.
    metadata.create_all(bind=engine)

    with Session() as sess:
        main_action: str = ''
        while main_action != menu_main.last_action():
            main_action = menu_main.menu_prompt()
            print('next action: ', main_action)
            exec(main_action)
        sess.commit()
    print('Ending normally')